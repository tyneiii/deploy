import Soon from "../layout/Soon";

const PfpEditor = () => {
  return (
    <>
      <Soon />
    </>
  );
}

export default PfpEditor;