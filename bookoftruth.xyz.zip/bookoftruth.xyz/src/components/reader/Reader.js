import Soon from "../layout/Soon";

const Reader = () => {
  return (
    <>
      <Soon />
    </>
  );
}

export default Reader;