import Soon from "../layout/Soon";

const Store = () => {
  return (
    <>
      <Soon />
    </>
  );
}

export default Store;